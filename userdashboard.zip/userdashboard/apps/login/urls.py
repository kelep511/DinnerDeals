from django.conf.urls import url, include
from . import views

urlpatterns = [
    url(r'^$', views.splash, name='index'),
    url(r'^signin$', views.index, name='signin'),
    url(r'^process$', views.process, name='process'),
    url(r'^register$', views.register, name='register'),
    url(r'^login$', views.login, name="login"),
    url(r'^logout$', views.logout, name='logout'),
    url(r'^dashboard/admin$', views.admin, name='admin'),
    url(r'^dashboard$', views.dash, name='dash'),
    url(r'^users/new$', views.addnew, name='addnew'),
    url(r'^users/edit$', views.selfedit, name='edit'),
    url(r'^users/edit/(?P<u_id>\d+)$', views.edit, name='edituser'),
    url(r'^delete$', views.delete, name='delete'),

]
